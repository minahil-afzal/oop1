﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4.BL
{
    public class Circle : Shape
    {
        protected double radius;
        public Circle(string name, double radius) : base(name)
        {
            this.radius = radius;
        }
        public override double getArea()
        {
            return (3.14 * radius * radius);
        }
        public override string toString()
        {
            return base.toString() + " and its area is: " + (3.14 * radius * radius);
        }
    }
}
