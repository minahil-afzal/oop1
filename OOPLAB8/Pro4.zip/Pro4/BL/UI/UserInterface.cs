﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4.BL.UI
{
    class UserInterface
    {
        public static List<Shape> list = new List<Shape>();
        public static Rectangle takeRectangle()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter " + name + " width: ");
            int width = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter " + name + " height: ");
            int height = int.Parse(Console.ReadLine());
            Rectangle rect = new Rectangle(name, height, width);
            return rect;
        }
        public static Square takeSquare()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter " + name + " width: ");
            int side = int.Parse(Console.ReadLine());
            Square sqr = new Square(name, side);
            return sqr;
        }
        public static Circle takeCircle()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter " + name + " radius: ");
            double radius = double.Parse(Console.ReadLine());
            Circle cir = new Circle(name, radius);
            return cir;
        }
        public static void addIntoList(Shape s)
        {
            list.Add(s);
        }
        public static int mainMenu()
        {
            int option;
            Console.WriteLine("1. Add rectangle");
            Console.WriteLine("2. Add Square");
            Console.WriteLine("3. Add Circle");
            Console.WriteLine("4. Get Area");
            Console.WriteLine("5. Exit");
            Console.WriteLine("               ");
            Console.WriteLine("Enter your option: ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        public static void showAllShapes()
        {
            foreach (Shape s in list)
            {
                Console.WriteLine(s.toString());
            }
        }
    }
}
