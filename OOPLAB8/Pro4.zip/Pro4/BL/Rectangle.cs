﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4.BL
{
    public class Rectangle : Shape
    {
        protected int height;
        protected int width;
        public Rectangle(string name, int height, int width) : base(name)
        {
            this.height = height;
            this.width = width;
        }
        public override double getArea()
        {
            return height * width;
        }
        public override string toString()
        {
            return base.toString() + " and its area is: " + (height * width);
        }
    }
}
