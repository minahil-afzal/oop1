﻿using Pro3.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro3.DL
{
    public class AnimalDL
    {
        public static List<Mammal> list = new List<Mammal>();
        public static Dog takeDogName()
        {
            Console.WriteLine("Enter dog name: ");
            string name = Console.ReadLine();
            Dog dog = new Dog(name);
            return dog;
        }
        public static Cat takeCatName()
        {
            Console.WriteLine("Enter cat name: ");
            string name = Console.ReadLine();
            Cat cat = new Cat(name);
            return cat;
        }
        public static void addIntoList(Mammal m)
        {
            list.Add(m);
        }
    }
}
