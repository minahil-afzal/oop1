﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro3.BL
{
    public class Cat : Mammal
    {

        public Cat(string name) : base(name)
        {
            this.name = name;
        }
        public void greets()
        {
            Console.WriteLine("Meow");
        }
        public override string toString()
        {
            return "Cat : Cat[Mammal[Animal[name=" + name + "]]]";
        }
    }
}
