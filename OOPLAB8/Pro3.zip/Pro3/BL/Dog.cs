﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro3.BL
{
    public class Dog : Mammal
    {
        public Dog(string name) : base(name)
        {
            this.name = name;
        }
        public void greets()
        {
            Console.WriteLine("Woof");
        }
        public override string toString()
        {
            return "Dog : Dog[Mammal[Animal[name=" + name + "]]]";
        }
    }
}
