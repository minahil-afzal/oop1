﻿using Pro2.BL;
using Pro2.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro2
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 2; i++)
            {
                Student s = PersonDL.takeStudentInput();
                PersonDL.addIntoList(s);
                Staff staffs = PersonDL.takeStaffInput();
                PersonDL.addIntoList(staffs);
                string allStu = s.toString();
                Console.WriteLine(allStu);
                string allstf = staffs.toString();
                Console.WriteLine(allstf);
            }
        }
    }
}
