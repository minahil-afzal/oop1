﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro2.BL
{
    class MountainBike : Bicycle
    {
        protected int seatHeight;

        public MountainBike() : base()
        {
        }

        public MountainBike(int seatHeight, int candence, int speed, int gear) : base(candence, gear, speed)
        {
            this.seatHeight = seatHeight;
            this.candence = candence;
            this.speed = speed;
            this.gear = gear;
        }

        public void setHeight(int height)
        {
            this.seatHeight = height;
        }
    }
}
