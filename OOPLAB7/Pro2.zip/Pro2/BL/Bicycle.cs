﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro2.BL
{
    class Bicycle
    {
        protected int candence;
        protected int gear;
        protected int speed;

        public Bicycle()
        {

        }

        public Bicycle(int candence, int speed, int gear)
        {
            this.candence = candence;
            this.gear = gear;
            this.speed = speed;
        }

        public void setCandence(int candence)
        {
            this.candence = candence;
        }

        public void showCandence()
        {
            Console.WriteLine(this.candence);
        }

        public void setGear(int gear)
        {
            this.gear = gear;
        }

        public void showGear()
        {
            Console.WriteLine(this.gear);
        }

        public void applyBrake(int decrement)
        {
            
            this.speed = this.speed - decrement;
        }

        public int showDecre()
        {
            return this.speed;
        }

        public void speedUp(int increment)
        {
           this.speed = this.speed + increment;
        }

        public int showIncre()
        {
            return this.speed;
        }
    }
}
