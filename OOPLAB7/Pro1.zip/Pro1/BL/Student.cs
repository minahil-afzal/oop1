﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro1.BL
{
    class Student
    {
        public string name;
        public string session;
        public bool isDayScholar;
        public int entryTestMarks;
        public int HSMarks;

        public double calculateMerit()
        {
            double merit = 0.0;
            merit = ((60 * entryTestMarks) / 100) + ((40 * HSMarks) / 100);

            return merit;
        }
    }
}
